#include "matrixmul/matrixmul.h"
#include <time.h>

#ifndef APPLICATION_H
#define APPLICATION_H

/*======================================================================================*/
/*                              TYPES DEFINITIONS                                       */
/*======================================================================================*/
clock_t start_time;
clock_t end_time;
double execution_time;

/*======================================================================================*/
#endif